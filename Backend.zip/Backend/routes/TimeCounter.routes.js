import express from "express";
import {TimeTrackingofUser} from "../Controllers/TimeCounterData.controllers.js";

const router = express.Router();
router.post("/TimeTrackingofUser", TimeTrackingofUser);

export default router;